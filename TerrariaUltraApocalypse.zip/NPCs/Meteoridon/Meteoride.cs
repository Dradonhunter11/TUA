﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TerrariaUltraApocalypse.API;

namespace TerrariaUltraApocalypse.NPCs.Meteoridon
{
    class Meteoride
    {
    }
}
