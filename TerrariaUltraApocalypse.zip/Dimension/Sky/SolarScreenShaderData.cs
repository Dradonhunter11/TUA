﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Terraria.Graphics.Shaders;

namespace TerrariaUltraApocalypse.Dimension.Sky
{
    class SolarScreenShaderData : ScreenShaderData
    {
        //soon
        public SolarScreenShaderData(string passName) : base(passName)
        {
        }


    }
}