﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria.UI;

namespace TerrariaUltraApocalypse.UIHijack.WorldSelection.ModElement
{
    class VanillaElement : UIElement
    {
        public override void OnInitialize()
        {
            
        }


    }
}
