﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;
using Terraria.ModLoader;

namespace TerrariaUltraApocalypse.API.TerraEnergy.MachineRecipe
{
    class BaseRecipe
    {
        private String result;
        private Mod mod;
        private List<String> ingredient;


    }
}
