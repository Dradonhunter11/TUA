﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Terraria;

namespace TerrariaUltraApocalypse.API.CustomInventory
{
    abstract class BasicInventory
    {
        private List<ExtraSlot> inventory = new List<ExtraSlot>();
        


        

    }



}
